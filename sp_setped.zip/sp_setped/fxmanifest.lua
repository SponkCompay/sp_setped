fx_version 'cerulean'
game 'gta5'

author 'Sponk Compay'
description 'Script para poner una ped Custom'
version '1.0'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}
